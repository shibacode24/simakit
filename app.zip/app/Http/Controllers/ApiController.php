<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;
use App\Models\User;
use App\Models\cmakeit;
use Hash;

class ApiController extends Controller
{
    public function login(Request $request)
    {
        $checkuser = User::where('name', $request->username)->first();
        if ($checkuser && Hash::check($request->password, $checkuser->password)) {
            return response()->json(['status' => true, 'data' => $checkuser]); //array
        } else {
            return response()->json(['status' => false, 'message' => 'User Not Found']); //array
        }
    }


    public function survey(Request $request){
        $insert = cmakeit::create([
            'survey_number' => $request->survey_number,
            'establishment_name' => $request->establishment_name,
            'image' => $request->image,
         
           
           
        ]);
        if($insert) {
            return response()->json(['status' => true, 'message' => 'Data Has Been Submitted']);
        } else {
            return response()->json(['status' => false, 'message' => 'data not found']);
        
        }
        
    }  

}

//simakeit
