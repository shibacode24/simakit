
<?php $__env->startSection('content'); ?>
		<!--start page wrapper -->
		<div class="page-wrapper">
			<div class="page-content">
				<div class="row">
					<div class="col-md-8 mx-auto" >
					
				
			</div>



				<div class="overlay toggle-icon"></div>
				<h6>SURVEY FORM Show</h6>
				<hr/>
				<div class="col-md-12 mx-auto">
				<div class="card">
					<div class="card-body">
						<div class="table-responsive">
							<table id="example" class="table table-striped table-bordered">
								<thead>
									<tr>	
										<th>Sr. No.</th>
										<th>Serve Application Number</th>
										<th>Name of Establishment</th>
							            <th>Locality</th>
							            <th>Ward/Prabhag Name/No</th>
							            <th>Pin Code</th>
										<th>Whatsapp No</th>
										<th>Email ID</th>
										<th>GST No</th>
										<th>Year of Starting of Business</th>
										<th>Nature of Business</th>
										<th>Number of Employees Working as on date</th>
										<th>Area of Business in square Feet</th>
										
										<th style="background-color: #fff">Action</th>
									</tr>
								</thead>
								<tbody>
									<?php $__currentLoopData = $serve_all; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $serve_all): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
									<tr>
										<td><?php echo e($loop->index+1); ?></td>
										<td><?php echo e($serve_all->survey_app_no); ?></td>
										<td
										data-bs-toggle="tooltip" data-bs-placement="top" title=
										"
										 BUssiness Owner :- <?php echo e($serve_all->bussiness_owner); ?> 
										Contact_Person :- <?php echo e($serve_all->contact_person); ?>

										Street_Name :- <?php echo e($serve_all->street_name); ?>

										Shop_ House_ NO :- <?php echo e($serve_all->shop_house_no); ?>

										Building Name :- <?php echo e($serve_all->bulding); ?>			
										" 
										
										><?php echo e($serve_all->establishment); ?></td>
									
									
										<td><?php echo e($serve_all->locality); ?></td>	
										<td><?php echo e($serve_all->prabhag_name); ?></td>	
										<td><?php echo e($serve_all->pincode); ?></td>	
										<td><?php echo e($serve_all->wht_app_no); ?></td>
										<td><?php echo e($serve_all->email); ?></td>	
										<td><?php echo e($serve_all->gst_no); ?></td>
										<td><?php echo e($serve_all->year); ?></td>	
										<td><?php echo e($serve_all->nature_of_bussiness); ?></td>	
										<td><?php echo e($serve_all->no_of_employee_working); ?></td>	
										<td><?php echo e($serve_all->area_of_bussiness); ?></td>	
								
										<td style="background-color: #fff">
											<a href="<?php echo e(route('newserveedit',$serve_all->id)); ?>"><button type="button" class="btn1 btn-outline-success"><i class='bx bx-edit-alt me-0'></i></button> </a>
											<a href="<?php echo e(route('newservedelete',$serve_all->id)); ?>"><button type="button" class="btn1 btn-outline-danger" onclick="return confirm('Are You Sure To Delete This?')"><i class='bx bx-trash me-0'></i></button> </a>
										</td>										
							
									</tr>
									<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

							
								</tbody>
							</table>
						</div>
					</div>
				</div>
			</div>
			</div>
		</div>	
		<?php $__env->stopSection(); ?>		
				
			
				
				
				
	
<?php echo $__env->make('layout', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\wamp64\www\cmakeit\resources\views/ServeForm/show.blade.php ENDPATH**/ ?>