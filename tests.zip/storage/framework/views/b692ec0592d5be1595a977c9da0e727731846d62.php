
<?php $__env->startSection('content'); ?>
		<!--start page wrapper -->
		<div class="page-wrapper">
			<div class="page-content">
				<div class="row">
					<div class="col-md-6 mx-auto" >
					<?php echo $__env->make('alert', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
				<div class="card">
					<div class="card-body">
						<div class="card-title d-flex align-items-center">

							<h6>City Master</h6>
						</div>
						<hr>
						<form class="row g-2" method="post" action="<?php echo e(route('cityinsert')); ?>">
							<?php echo csrf_field(); ?>

							<div class="col-md-3"></div>
							<div class="col-md-4">
								<label>City Name</label>
								<input class="form-control mb-3" type="text" placeholder="City" name="city">
								
							</div>
							<div class="col-md-4" style="margin-top:30px;">
								<div class="col">
									<button type="submit" class="btn btn-primary px-5"> <i class="lni lni-circle-plus"></i>Add</button>
								</div>
							</div>



						</form>

					</div>

				</div>
					</div>
				</div>


                <div class="overlay toggle-icon"></div>
				<hr/>
				<div class="col-md-6 mx-auto">
				<div class="card">
					<div class="card-body">
						<div class="table-responsive">
							<table id="example" class="table table-striped table-bordered">
								<thead>
									<tr>	
										<th>Sr. No.</th>
										<th>City Name</th>  
										<th>Action</th>
									</tr>
								</thead>
								<tbody>
									<?php $__currentLoopData = $city_all; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $city_all): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
									<tr>
										<td><?php echo e($loop->index + 1); ?></td>
										<td><?php echo e($city_all->city); ?></td>	
										<td>
											<a href="<?php echo e(route('cityedit',$city_all->id)); ?>"><button type="button" class="btn1 btn-outline-success"><i class='bx bx-edit-alt me-0'></i></button> </a>
											<a href="<?php echo e(route('citydelete',$city_all->id)); ?>"><button type="button" class="btn1 btn-outline-danger" onclick="return confirm('Are You Sure To Delete This?')"><i class='bx bx-trash me-0'></i></button> </a>
										</td>										
							
									</tr>
									<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
									
							
								</tbody>
							</table>
						</div>
					</div>
				</div>
			</div>
			</div>
		</div>			
<?php $__env->stopSection(); ?>
							
				
				<!--end page wrapper -->
				<!--start overlay-->
				
				
				
				
		
<?php echo $__env->make('layout', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\wamp64\www\cmake\resources\views/Master/city.blade.php ENDPATH**/ ?>